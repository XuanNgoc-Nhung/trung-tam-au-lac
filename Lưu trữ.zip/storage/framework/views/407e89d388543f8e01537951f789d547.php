<footer class="footer">
    <div class="footer-content">
        <div class="row">
            <div class="col-md-6">
                
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-0">
                    <i class="fas fa-code me-1"></i>
                    <?php echo $__env->yieldContent('footer-developer', 'Phát triển bởi <strong>Team Development</strong>'); ?>
                </p>
            </div>
        </div>
        <?php echo $__env->yieldContent('footer-additional'); ?>
    </div>
</footer> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quanLyKhoaHoc/resources/views/layouts/footer.blade.php ENDPATH**/ ?>